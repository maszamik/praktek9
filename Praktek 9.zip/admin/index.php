<?php
session_start();
if(isset($_SESSION['username'])){

	header("location:cetak.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="login.css">
	<title>Login Halaman Admin</title>
</head>
<body>

<div id="main">
	<h1><center> Program Rifqi </center></h1>
	<div id="login">
		<h2>Halaman Admin</h2>
		<form action="login_proses.php" method="post">
			<label>User Name :</label>
			<input id="name" name="username" placeholder="Silahkan Masukkan Username" type="text">

			<label>Password :</label>
			<input id="password" name="password" placeholder="Silahkan Masukkan Password" type="password">

			<input name="login" type="submit" value=" Login "><br>
		</form>
	</div>
</div>
</body>
</html>