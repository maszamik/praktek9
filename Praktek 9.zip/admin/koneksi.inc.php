<?php
$host='localhost';
$username='miknetwo_20082010159';
$password='miknetwo_20082010159';
$dbname='miknetwo_20082010159';
$conn = mysqli_connect($host, $username, $password, $dbname) or die("Koneksi gagal dibangun");

?>